#include "calculator.h"

// Function to clear Winsock resources if using Windows
void clearwinsock() {
#if defined WIN32
    WSACleanup(); // Cleans up the Winsock library resources
#endif
}

// Function to clear the screen based on the operating system
void clearScreen() {
#if defined WIN32
    system("cls"); // Clears the console screen on Windows
#else
    system("clear"); // Clears the console screen on other systems (e.g., Unix/Linux)
#endif
}

// Function to handle error messages
void errorhandler(const char *error_message) {
    printf("%s\n", error_message); // Prints the error message passed as an argument
}

// Main function
int main(int argc, char *argv[]) {
#if defined WIN32
    // Initialize Winsock for Windows platforms
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data); // Initializes Winsock library
    if (result != NO_ERROR) {
        printf("Error at WSAStartup()\n");
        return 0;
    }
#endif

    char* buffer = malloc(BUFFMAX); // Allocate memory for a buffer
    char serverName[BUFFMAX];
    int port;

    // Check if command line arguments are provided
    if (argc == 3) {
        strcpy(serverName, argv[1]); // Copy server name from command line argument
        port = atoi(argv[2]); // Convert port number from string to integer
    } else {
        // Use default values if not provided via command line
        strcpy(serverName, "srv.di.uniba.it"); // Default server name
        port = 56700; // Default port number
    }

    // Retrieve host information by name
    struct hostent *host = gethostbyname(serverName);
    if (host == NULL) {
        errorhandler("Error getting host"); // Display error message if host information retrieval fails
        clearwinsock(); // Clean up Winsock resources
        free(buffer); // Free allocated memory
        return EXIT_FAILURE; // Return failure status
    }

    // Variables for socket communication
    int my_socket;
    struct sockaddr_in server_address;
    int server_address_size = sizeof(server_address);
    int rcv_msg_size;

    // Create a UDP socket
    if ((my_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        errorhandler("Error creating socket"); // Display error message if socket creation fails
        clearwinsock(); // Clean up Winsock resources
        free(buffer); // Free allocated memory
        return EXIT_FAILURE; // Return failure status
    }

    // Initialize server address structure
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(port);
    server_address.sin_addr = *((struct in_addr*) host->h_addr);

    // Loop for client-server interaction
    while (1) {
        clearScreen(); // Clear the console screen
        printf("Server name: %s (IP: %s, port: %d)\n", serverName, inet_ntoa(*(struct in_addr*) host->h_addr), port);
        puts("Enter the operands in this order (operator operand operand)");
        puts("Enter '=' as the operator to interrupt the connection with the server");
        printf("Enter: ");
        memset(buffer, 0, BUFFMAX); // Clear the buffer
        fgets(buffer, BUFFMAX, stdin); // Read input from user
        buffer[strlen(buffer)-1]='\0'; // Remove newline character

        // Check if the user wants to terminate the connection
        if(buffer[0] == '=' && buffer[1] == ' '){
            puts("Client terminated. Press any key to continue...");
            getch(); // Wait for user input
            closesocket(my_socket); // Close the socket
            clearwinsock(); // Clean up Winsock resources
            free(buffer); // Free allocated memory
            return EXIT_FAILURE; // Return failure status
        }

        // Send data to the server
        if (sendto(my_socket, buffer, strlen(buffer), 0, (struct sockaddr*) &server_address, sizeof(server_address)) != strlen(buffer)) {
            errorhandler("Error sending data"); // Display error message if sending data fails
            closesocket(my_socket); // Close the socket
            clearwinsock(); // Clean up Winsock resources
            free(buffer); // Free allocated memory
            return EXIT_FAILURE; // Return failure status
        }

        // Receive data from the server
        memset(buffer, 0, BUFFMAX); // Clear the buffer
        if ((rcv_msg_size = recvfrom(my_socket, buffer, BUFFMAX, 0, (struct sockaddr*) &server_address, &server_address_size)) < 0) {
            errorhandler("Error receiving data"); // Display error message if receiving data fails
            closesocket(my_socket); // Close the socket
            clearwinsock(); // Clean up Winsock resources
            free(buffer); // Free allocated memory
            return EXIT_FAILURE; // Return failure status
        }

        // Display received message from the server
        printf("Message received from %s, ip %s: %s\n", inet_ntoa(*(struct in_addr*) host->h_addr), inet_ntoa(*(struct in_addr*) host->h_addr), buffer);
        puts("Press any key to continue...");
        getch(); // Wait for user input
    }

    closesocket(my_socket); // Close the socket
    clearwinsock(); // Clean up Winsock resources
    free(buffer); // Free allocated memory
    return EXIT_SUCCESS; // Return success status
}
