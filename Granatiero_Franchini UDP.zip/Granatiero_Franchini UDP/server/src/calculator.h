
#ifndef CALCULATOR_H_
#define CALCULATOR_H_

#if defined WIN32
#include <winsock.h>
#include <windows.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NO_ERROR 0
#define BUFFMAX 255
#define PORT 56700

#endif /* CALCULATOR_H_ */
